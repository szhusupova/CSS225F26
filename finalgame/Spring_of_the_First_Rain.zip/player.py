# player.py
# This file has the Player class. A class is like a blueprint: it keeps
# all the information about one character together in one object and has
# functions (called methods) that work with that information.


class Player:

    # __init__ runs when we create a new Player, like: Player("Nurkamil")
    def __init__(self, name):
        self.name = name              # the hero's name
        self.supplies = 0             # bought in chapter 1
        self.clues = 0                # earned in chapter 2
        self.wisdom = 0               # earned in chapters 2, 3 and 4
        self.items = []               # list of things the hero carries
        self.withAigerim = False      # True if Aigerim joined in chapter 3
        self.savedChoice = ""         # "aigerim" or "supplies" in chapter 5

    # Add more supplies to the hero
    def add_supplies(self, amount):
        self.supplies = self.supplies + amount

    # Use up supplies
    def use_supplies(self, amount):
        self.supplies = self.supplies - amount

    # Check if the hero has at least this many supplies (True or False)
    def has_supplies(self, amount):
        return self.supplies >= amount

    # Add wisdom points
    def add_wisdom(self, amount):
        self.wisdom = self.wisdom + amount

    # Add an item to the list, but only if the hero does not have it yet
    def add_item(self, item):
        if item not in self.items:
            self.items.append(item)

    # Print everything about the hero
    def profile(self):
        print("\n--- Hero profile ---")
        print("Name:", self.name)
        print("Supplies:", self.supplies)
        print("Clues:", self.clues)
        print("Wisdom:", self.wisdom)
        print("Items:", self.items)
        print("Aigerim joined:", self.withAigerim)


# Unit test: runs only when this file is run by itself
if __name__ == '__main__':
    hero = Player("Test Hero")
    hero.add_supplies(5)
    hero.use_supplies(3)
    hero.add_wisdom(2)
    hero.add_item("map piece")
    hero.add_item("map piece")        # should not be added twice
    print("Has 2 supplies:", hero.has_supplies(2))   # True
    print("Has 3 supplies:", hero.has_supplies(3))   # False
    hero.profile()
