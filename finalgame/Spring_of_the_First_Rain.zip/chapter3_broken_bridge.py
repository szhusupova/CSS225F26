# Chapter 3 - The Broken Bridge
# This module has the actions that happen at the river.
# It follows the Chapter 3 flowchart from Milestone 2.
import globalvars
from random import shuffle, randint


# Nurkamil reads the signs of nature around the river.
def read_signs():
    signs = ["The birds fly low. A storm may be coming.",
             "The water is calm near the old stones.",
             "The wind blows from the mountains.",
             "Wolf tracks lead along the river bank."]
    shuffle(signs)
    print("\nNurkamil reads the signs of nature:")
    print(signs[0])


# Nurkamil meets Aigerim the guide.
def meet_aigerim():
    print("\nA young woman steps out from behind the rocks.")
    print("Aigerim: I am Aigerim. I know these mountains well.")


# Nurkamil must choose to take a risk or to plan.
# If a fast bridge collapses, rebuilding it costs 3 supplies.
def build_bridge():
    print("\nThe bridge is collapsed. How will you cross the river?")
    print("1 - Risk: build fast")
    print("2 - Plan: plan carefully")
    choice = input("Type 1 or 2: ")

    if choice == "1":
        print("Nurkamil builds a bridge as fast as he can...")
        # randint(1, 2) gives 1 or 2, so it is a 50/50 chance
        if randint(1, 2) == 1:
            print("The risk succeeds! The bridge holds.")
        else:
            print("The bridge collapses! Nurkamil rebuilds it carefully.")
            print("The new bridge uses up 3 supplies.")
            globalvars.player.use_supplies(3)
    else:
        print("Nurkamil plans carefully and builds a strong bridge.")


# Aigerim offers to guide Nurkamil.
def aigerim_guidance():
    print("\nAigerim: Let me come with you. The mountains are dangerous.")
    answer = input("Accept her guidance? Press y for yes or n for no: ")

    if answer == "y":
        print("Aigerim joins Nurkamil on the journey.")
        globalvars.player.withAigerim = True
        globalvars.player.add_wisdom(1)
    else:
        print("Nurkamil continues alone.")
        globalvars.player.withAigerim = False


# This runs the whole chapter. It sets globalvars.chapter3_success
# If Nurkamil goes alone and has only 1 clue, he gets lost (not success).
def main():
    print("\n=== CHAPTER 3: THE BROKEN BRIDGE ===")
    print("Nurkamil reaches the river. The bridge is collapsed.")

    read_signs()
    meet_aigerim()
    build_bridge()
    print("Nurkamil crosses the river.")
    aigerim_guidance()

    # "and" is True only when BOTH sides are True
    if globalvars.player.withAigerim == False and globalvars.player.clues <= 1:
        globalvars.chapter3_success = False
    else:
        print("Chapter 3 complete!")
        globalvars.chapter3_success = True


# Unit test: runs only when this file is run by itself
if __name__ == '__main__':
    globalvars.init_global_vars()
    globalvars.player.supplies = 5     # pretend we finished chapter 1
    globalvars.player.clues = 3        # pretend we finished chapter 2
    main()
    print("TEST RESULT -> success:", globalvars.chapter3_success,
          " with Aigerim:", globalvars.player.withAigerim,
          " supplies:", globalvars.player.supplies)
