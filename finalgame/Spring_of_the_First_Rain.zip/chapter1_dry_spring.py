# Chapter 1 - The Dry Spring
# This module has the actions that happen in Nurkamil's village.
# It follows the Chapter 1 flowchart from Milestone 2.
import globalvars
from random import shuffle, randint


# This will create a randomly named villager to talk to
def villager():
    # Below is a list. We can store lots of things in a list
    # and then retrieve them later.
    responses = ["The spring has been dry since winter.",
                 "My sheep are thirsty. Please help us!",
                 "The akyn knows an old legend about the spring.",
                 "Have you seen how low the river is?"]
    npcNameChoice = ["Bolot", "Aida", "Marat", "Gulnara"]

    # Shuffle will shuffle the list contents into a random order
    shuffle(npcNameChoice)
    shuffle(responses)
    npcName = npcNameChoice[0]

    print(npcName, ": Hello", globalvars.player.name,
          ", would you like to talk to me?")
    answer = input("Press y to talk to the villager: ")

    if answer == "y":
        print(npcName, ":", responses[0])
    else:
        print(npcName, ": Goodbye.")


# Nurkamil visits the akyn (storyteller) and hears the legend.
# It gives back True if Nurkamil accepts the journey, False if not.
def akyn():
    print("\nThe akyn plays his komuz and begins to tell the legend:")
    print("'The Spring of the First Rain lies beyond the high mountains.")
    print("Only someone brave can find it and bring the water back.'")
    answer = input("Do you accept the journey? Press y for yes or n for no: ")

    if answer == "y":
        print("Akyn: May the mountains be kind to you,", globalvars.player.name)
        return True
    else:
        print("Akyn: Then we must wait for the rain...")
        return False


# Nurkamil sells felt carpets to buy supplies.
# He has 5 carpets and needs 5 supplies. If he does not have
# enough supplies yet, he goes back and sells another carpet.
def sell_carpets():
    carpets = 5
    supplies = 0
    suppliesNeeded = 5

    print("\nNurkamil takes his felt carpets to the market.")

    # This loop repeats until we have enough supplies
    while supplies < suppliesNeeded:
        print("Supplies:", supplies, "/", suppliesNeeded,
              "  Carpets left:", carpets)
        answer = input("Press s to sell a carpet: ")

        if answer == "s" and carpets > 0:
            carpets = carpets - 1
            gained = randint(1, 2)
            supplies = supplies + gained
            print("You sold a carpet and bought", gained, "supplies.")
        else:
            print("You still need more supplies for the journey.")

    print("You have enough supplies now!")
    globalvars.player.supplies = supplies


# This runs the whole chapter. It sets globalvars.chapter1_success
def main():
    print("\n=== CHAPTER 1: THE DRY SPRING ===")
    print("Nurkamil wakes at dawn in the village. The spring is dry.")

    villager()

    if akyn() == False:
        print("\nEARLY ENDING: The spring stays dry.")
        globalvars.chapter1_success = False
        return

    sell_carpets()
    print("\nNurkamil leaves for the high pass.")
    print("Chapter 1 complete!")
    globalvars.chapter1_success = True


# This part only runs when we run this file by itself (unit test).
# It does not run when maingame.py imports this file.
if __name__ == '__main__':
    globalvars.init_global_vars()
    main()
    print("TEST RESULT -> success:", globalvars.chapter1_success,
          " supplies:", globalvars.player.supplies)
