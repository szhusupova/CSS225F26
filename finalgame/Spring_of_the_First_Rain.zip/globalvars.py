# Global variables used across my game: The Spring of the First Rain
# Every chapter does "import globalvars" so they all share these values.
# Most of the hero's information lives inside the Player object (player.py).
from player import Player


# This sets the starting values. maingame.py calls it once at the start
# (and again if the player decides to play a new game).
def init_global_vars():
    global player
    global currentChapter
    global chapter1_success
    global chapter2_success
    global chapter3_success
    global chapter4_success
    global chapter5_success

    player = Player("Nurkamil")   # a new Player object (supplies, wisdom...)
    currentChapter = 1            # which chapter the player is in now

    # Each chapter sets its own flag to True when the player succeeds
    chapter1_success = False
    chapter2_success = False
    chapter3_success = False
    chapter4_success = False
    chapter5_success = False


def main():
    # Unit test: print the starting values
    init_global_vars()
    print("Chapter:", currentChapter)
    player.profile()


if __name__ == '__main__':
    main()
