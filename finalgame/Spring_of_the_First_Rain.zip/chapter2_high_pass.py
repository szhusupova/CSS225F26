# Chapter 2 - The High Pass
# This module has the actions that happen at the yurt camp.
# It follows the Chapter 2 flowchart from Milestone 2.
import globalvars
from random import shuffle


# This will create a randomly named shepherd to meet
def shepherd_family():
    familyNames = ["Askar", "Zarina", "Erlan", "Aliya"]
    shuffle(familyNames)
    shepherdName = familyNames[0]

    print("\nA shepherd family welcomes you to their yurt camp.")
    print(shepherdName, ": Salam, traveler! Where are you going?")
    print(globalvars.player.name,
          ": I am looking for the Spring of the First Rain.")
    return shepherdName


# Nurkamil can help with the herd. Helping earns trust.
# It sets how many clues Nurkamil can learn.
def help_with_herd(shepherdName):
    print(shepherdName, ": Our sheep ran off. Can you help us gather them?")
    answer = input("Help with the herd? Press y for yes or n for no: ")

    if answer == "y":
        print("You gather the herd together. The family trusts you now.")
        globalvars.player.clues = 3
        globalvars.player.wisdom = 1
    else:
        print("You walk away. The family does not trust you much.")
        globalvars.player.clues = 1
        globalvars.player.wisdom = 0


# Nurkamil shares a meal and gains knowledge from the family.
# We show as many clues from the list as we earned.
def share_meal(shepherdName):
    allClues = ["The river is east of the pass.",
                "A broken bridge is on the way.",
                "The eagle knows the way to the lake."]

    print("\nThe family shares beshbarmak with you.")
    print(shepherdName, ": Let me tell you what I know.")

    # This loop runs once for each clue we earned
    number = 0
    while number < globalvars.player.clues:
        print("Clue:", allClues[number])
        number = number + 1


# Nurkamil finds the old map piece.
def find_map_piece():
    print("\nBefore you leave, you find an old map piece under a carpet.")
    print("It shows a river and the picture of an eagle.")
    globalvars.player.add_item("old map piece")


# This runs the whole chapter. It sets globalvars.chapter2_success
def main():
    print("\n=== CHAPTER 2: THE HIGH PASS ===")
    print("Nurkamil arrives at the yurt camp.")

    shepherdName = shepherd_family()
    help_with_herd(shepherdName)
    share_meal(shepherdName)
    find_map_piece()

    print("\nAn eagle flies above you. Nurkamil follows it to the river.")
    print("Chapter 2 complete!")
    globalvars.chapter2_success = True


# Unit test: runs only when this file is run by itself
if __name__ == '__main__':
    globalvars.init_global_vars()
    main()
    print("TEST RESULT -> success:", globalvars.chapter2_success,
          " clues:", globalvars.player.clues, " wisdom:", globalvars.player.wisdom)
