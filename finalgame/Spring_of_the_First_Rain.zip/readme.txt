================================================================
THE SPRING OF THE FIRST RAIN  -  Technical Documentation
================================================================
Project type : Text-based adventure game (command line)
Author       : Sezimgul Zhusupova
Course       : CSS 225 - Final Project
Version      : 1.0 (November 2026)

This document is for developers who join the project and for
administrators who need to run and maintain the game.


----------------------------------------------------------------
1. WHERE THE CODE IS HOSTED
----------------------------------------------------------------
GitHub repository : <PASTE YOUR GITHUB REPOSITORY URL HERE>
                    (example: https://github.com/<username>/spring-of-the-first-rain)

The repository holds the same files as the submitted .zip, not zipped.
To get the code:

    git clone <PASTE YOUR GITHUB REPOSITORY URL HERE>
    cd spring-of-the-first-rain


----------------------------------------------------------------
2. EXTERNAL SERVICES
----------------------------------------------------------------
None. The game runs fully offline. It uses no database, no web
service, no API keys and no network connection. It does not read or
write any files while it runs (nothing is saved between games).


----------------------------------------------------------------
3. LANGUAGES AND TECHNOLOGIES
----------------------------------------------------------------
- Language : Python 3
- Libraries: Python standard library only
              random  (shuffle, randint) - random names, riddles, chances
- No packages to install. There is no requirements.txt because
  nothing needs to be installed with pip.
- Concepts used: functions, modules (import), lists, while loops,
  if/elif/else, a class (Player), global variables shared through
  a module, and unit-test blocks (if __name__ == '__main__').


----------------------------------------------------------------
4. SYSTEM REQUIREMENTS AND SUPPORTED APPLICATIONS
----------------------------------------------------------------
- Python 3.8 or newer (developed and tested with Python 3.13)
- Any operating system that runs Python: Windows, macOS, Linux
- A terminal / command prompt, or an IDE that can run Python files
  and take keyboard input (IDLE, PyCharm, VS Code, Thonny)
- Almost no memory or disk space (about 20 KB of code)
- Note: the game uses input(), so it must be run in a place where you
  can type. Some online "run only" tools do not allow typing.


----------------------------------------------------------------
5. CODING AND NAMING CONVENTIONS
----------------------------------------------------------------
- File names     : lowercase. Chapter files are chapterN_name.py
                   (chapter1_dry_spring.py ...). Other files use one
                   lowercase word (maingame.py, player.py).
- Functions      : lowercase with underscores (sell_carpets, echo_riddle).
- Variables      : camelCase (npcName, suppliesNeeded, eagleAnswers),
                   the same style as the course example.
- Class names    : CapitalizedWords (Player).
- Success flags  : chapterN_success in globalvars.py (True/False).
- Comments       : every file starts with a comment saying what it does;
                   every function has a comment above it.
- Indentation    : 4 spaces. Line length is kept under about 80 characters.
- Each chapter file has a main() function that runs the chapter, and a
  unit-test block at the bottom:

      if __name__ == '__main__':
          ...

  This block runs ONLY when you run that file by itself, and does NOT run
  when maingame.py imports the file.


----------------------------------------------------------------
6. HOW TO RUN / BUILD / DEPLOY
----------------------------------------------------------------
Build : None. Python does not need to be compiled.

Deploy: Copy ALL of the .py files into ONE folder. The files import each
        other, so they must stay together. To "install" the game on
        another computer, copy that folder (or clone the GitHub repo).

Check : Run a quick test of any single file, for example:

            python chapter1_dry_spring.py

        Each file prints a line starting with "TEST RESULT" at the end.

Run all unit tests (one at a time):

    python player.py
    python globalvars.py
    python functions.py
    python chapter1_dry_spring.py
    python chapter2_high_pass.py
    python chapter3_broken_bridge.py
    python chapter4_echo_pass.py
    python chapter5_springs_secret.py

Common problems (for administrators):

  Problem                                   Fix
  ----------------------------------------  -------------------------------
  "python is not recognized" / not found    Try "python3" or "py" instead,
                                            or install Python from python.org
  ModuleNotFoundError: No module named      A file is missing or you are in
  'globalvars' (or chapterN_..., player)    the wrong folder. Make sure all
                                            files are in the same folder and
                                            run the command from that folder.
  EOFError: EOF when reading a line         The program needs keyboard input.
                                            Run it in a normal terminal/IDE.
  SyntaxError after editing                 Check indentation (4 spaces) and
                                            matching quotes.
  Game seems stuck in a loop                Chapter 1 repeats until you press
                                            "s" (sell) enough times; chapter 4
                                            repeats until the riddle is right.
                                            This is normal game behavior.


----------------------------------------------------------------
7. OVERVIEW OF THE ARCHITECTURE
----------------------------------------------------------------
The game is modular: each chapter is its own Python file, and a main
file decides which chapter to play next.

FILES
  maingame.py              Start file. Main loop that sends the player to
                           the next chapter or back to an earlier one.
  globalvars.py            Shared values: the Player object, the current
                           chapter number and the chapterN_success flags.
                           init_global_vars() resets them for a new game.
  player.py                The Player CLASS (see below).
  functions.py             Helper functions: fail_mesg(chapter) shows the
                           failure message, ask_yes_no(question) gives
                           True/False.
  chapter1_dry_spring.py   Chapter 1: villager(), akyn(), sell_carpets()
  chapter2_high_pass.py    Chapter 2: shepherd_family(), help_with_herd(),
                           share_meal(), find_map_piece()
  chapter3_broken_bridge.py Chapter 3: read_signs(), meet_aigerim(),
                           build_bridge(), aigerim_guidance()
  chapter4_echo_pass.py    Chapter 4: echo_riddle(), snowstorm(),
                           call_eagle()
  chapter5_springs_secret.py Chapter 5: avalanche(), learn_truth(),
                           clear_channel(), reflect()
  readme.txt               This document.

  Every chapter file also has main(), which calls its functions in the
  order of the flowchart and sets globalvars.chapterN_success.

HOW THE FILES CONNECT (imports)

                       maingame.py
          imports: chapter1..5, globalvars, functions
                          |
        +--------+--------+--------+--------+
        |        |        |        |        |
    chapter1 chapter2 chapter3 chapter4 chapter5
        \        \        |        /        /
         +--------+---- globalvars.py ------+
                          |
                       player.py  (class Player)

  The chapters import globalvars (and never maingame), so there is no
  circular import.

THE PLAYER CLASS (player.py)
  One Player object holds everything about the hero. It is created in
  globalvars.init_global_vars() as globalvars.player.

  Attributes:  name, supplies, clues, wisdom, items (list),
               withAigerim (True/False), savedChoice ("aigerim"/"supplies")
  Methods:     add_supplies(amount)   use_supplies(amount)
               has_supplies(amount) -> True/False
               add_wisdom(amount)     add_item(item)
               profile()  -> prints the hero's information

GLOBAL VARIABLES (globalvars.py)
  player           Player object shared by all chapters
  currentChapter   1 to 5; maingame.py reads this to pick the chapter
  chapter1_success ... chapter5_success   True when that chapter succeeded

  Chapters use them like:  globalvars.player.supplies
                           globalvars.chapter3_success = True

GAME FLOW (the logic in maingame.py)

  Ch1 --success--> Ch2 --> Ch3 --success--> Ch4 --success--> Ch5 --> End
   ^  \                     |                  |
   |   fail: try again?     fail: back to Ch2  fail: back to Ch1
   |   (yes = replay Ch1)
   +-----------------------------------------------+

  Ch1 fails   : player says no to the journey. Asked "try again?"
                (yes = Chapter 1 again, no = quit).
  Ch3 fails   : player goes alone AND has only 1 clue (did not help the
                herd in Ch2) -> sent BACK to Chapter 2.
  Ch4 fails   : player takes shelter in the storm but has fewer than
                3 supplies -> sent BACK to Chapter 1 for new supplies.
  Ch5 ends    : the village is saved. Asked "play again?"
                (yes = new game with a new Player, no = quit).

  Supplies matter: Chapter 3 rebuilding a collapsed bridge costs 3
  supplies, and Chapter 4 taking shelter costs 3 supplies.

STORY / DESIGN SOURCE
  The five chapters follow the flowcharts from Milestone 2:
  1 The Dry Spring, 2 The High Pass, 3 The Broken Bridge,
  4 The Echo Pass, 5 The Spring's Secret.

HOW TO ADD A NEW CHAPTER (for developers)
  1. Copy a chapter file and rename it (chapter6_name.py).
  2. Make main() set globalvars.chapter6_success.
  3. Add chapter6_success to init_global_vars() in globalvars.py.
  4. In maingame.py: import the file and add an "elif
     globalvars.currentChapter == 6:" block like the others.


----------------------------------------------------------------
8. HOW TO START THE PROGRAM (START THE GAME)
----------------------------------------------------------------
1. Put all the .py files in one folder.
2. Open a terminal / command prompt in that folder.
3. Type:

       python maingame.py

   (use "python3 maingame.py" on macOS/Linux if "python" does not work)

   In an IDE (IDLE, PyCharm, VS Code, Thonny): open maingame.py and
   press Run.

How to play:
  - Read the story text and type your answer at each prompt, then
    press Enter.
  - "Press y ..." / "Press s ..." / "Press a ..." prompts: type that
    letter.
  - "Type 1 or 2": type the number.
  - Riddles: type the answer in lowercase letters (for example: echo).
  - "(yes/no)" questions: type yes or no.

Tip for testing a single chapter: run that chapter file by itself, for
example "python chapter4_echo_pass.py".

================================================================
END OF DOCUMENT
================================================================
