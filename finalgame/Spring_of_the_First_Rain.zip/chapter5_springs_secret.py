# Chapter 5 - The Spring's Secret
# This module has the actions that happen at the frozen lake
# and when Nurkamil comes home.
# It follows the Chapter 5 flowchart from Milestone 2.
import globalvars


# An avalanche strikes! Nurkamil can save only one thing.
# It sets globalvars.player.savedChoice to "aigerim" or "supplies".
def avalanche():
    print("\nAn avalanche strikes the frozen lake!")
    if globalvars.player.withAigerim:
        print("Aigerim is stuck in the snow, and the supplies are sliding away.")
    else:
        print("Aigerim, who followed you from far away, is stuck in the snow.")
        print("The supplies are sliding away too.")
    print("1 - Save Aigerim")
    print("2 - Save the supplies")
    choice = input("Type 1 or 2: ")

    if choice == "1":
        print("Nurkamil pulls Aigerim out of the snow. The supplies are lost.")
        globalvars.player.savedChoice = "aigerim"
    else:
        print("Nurkamil grabs the supplies. Aigerim climbs out by herself.")
        globalvars.player.savedChoice = "supplies"


# Nurkamil learns the truth about the spring.
def learn_truth():
    print("\nUnder the ice, Nurkamil finds the Spring of the First Rain.")
    print("The spring is not gone. A channel is blocked by rocks and ice!")
    if globalvars.player.savedChoice == "aigerim":
        print("Aigerim: Together we can fix this.")
    else:
        print("Nurkamil: I have the tools in the supplies. I can fix this.")


# Nurkamil goes home and clears the blocked channel.
def clear_channel():
    print("\nNurkamil returns home to the village.")
    print("He goes to the blocked channel above the dry spring.")

    # Our ending depends on what we collected in the earlier chapters
    if globalvars.player.savedChoice == "aigerim" and globalvars.player.wisdom >= 3:
        print("Aigerim and Nurkamil use what the mountains taught them.")
        print("The ice breaks easily and the water flows.")
    elif globalvars.player.savedChoice == "aigerim":
        print("It is hard work, but Aigerim helps and the water flows.")
    else:
        print("Nurkamil works alone with the tools until the water flows.")


# Nurkamil thinks about his journey.
def reflect():
    print("\nNurkamil sits by the water and thinks about the journey.")
    print("He remembers the akyn, the shepherds and the echo in the pass.")
    if globalvars.player.savedChoice == "aigerim":
        print("He learned that friends are more important than supplies.")
    else:
        print("He learned that a hero must make hard choices.")
    globalvars.player.profile()


# This runs the whole chapter. It sets globalvars.chapter5_success
def main():
    print("\n=== CHAPTER 5: THE SPRING'S SECRET ===")
    print("Nurkamil reaches the frozen lake.")

    avalanche()
    learn_truth()
    clear_channel()
    reflect()

    print("\nTHE VILLAGE IS SAVED!")
    globalvars.chapter5_success = True


# Unit test: runs only when this file is run by itself
if __name__ == '__main__':
    globalvars.init_global_vars()
    globalvars.player.wisdom = 3       # pretend we collected wisdom
    globalvars.player.withAigerim = True
    main()
    print("TEST RESULT -> success:", globalvars.chapter5_success,
          " saved:", globalvars.player.savedChoice)
