# Chapter 4 - The Echo Pass
# This module has the actions that happen in the snowy pass.
# It follows the Chapter 4 flowchart from Milestone 2.
import globalvars
from random import shuffle, randint


# The echo asks a riddle. Each riddle is a list with
# three things: the question, the answer and a hint.
# If the answer is wrong the player gets a hint and tries again.
def echo_riddle():
    riddles = [["I speak without a mouth. What am I?", "echo",
                "You hear me in the mountains when you shout."],
               ["What is always coming but never arrives?", "tomorrow",
                "It is the day after today."],
               ["What follows you in the sun but disappears in the dark?",
                "shadow", "You can see it on the ground."]]
    shuffle(riddles)
    riddle = riddles[0]

    print("\nThe mountains whisper a riddle:")
    print(riddle[0])

    solved = False
    while solved == False:
        answer = input("Your answer: ")
        if answer.lower() == riddle[1]:
            print("The echo sings: Correct! You gain wisdom.")
            solved = True
        else:
            print("The echo whispers a hint:", riddle[2])
    globalvars.player.add_wisdom(1)


# A snowstorm hits. Nurkamil must turn his fear into strength.
# It gives back True if he can go on. Taking shelter uses 3 supplies,
# so if he has fewer than 3 supplies he cannot wait out the storm.
def snowstorm():
    print("\nA huge snowstorm covers the pass!")
    answer = input("Turn fear into strength? Press y for yes or n for no: ")

    if answer == "y":
        print("Nurkamil breathes deeply and walks through the storm.")
        globalvars.player.add_wisdom(1)
        return True
    else:
        print("Nurkamil takes shelter and waits for the storm to pass.")
        if not globalvars.player.has_supplies(3):
            return False
        globalvars.player.use_supplies(3)
        print("He eats 3 supplies while he waits.")
        return True


# Nurkamil sings a song to call the eagle.
# The eagle does not always answer, so he can try again.
def call_eagle():
    print("\nNurkamil sings the old song to call the eagle.")
    tries = 0
    eagleAnswers = False

    while eagleAnswers == False:
        tries = tries + 1
        # The eagle always answers on the third try
        if tries >= 3 or randint(1, 2) == 1:
            eagleAnswers = True
        else:
            print("No answer. Try the song again...")
            input("Press Enter to sing again: ")

    print("The eagle answers and leads you to the hidden lake!")


# This runs the whole chapter. It sets globalvars.chapter4_success
def main():
    print("\n=== CHAPTER 4: THE ECHO PASS ===")
    print("Nurkamil enters the snowy pass and hears the echo riddles.")

    echo_riddle()

    if snowstorm() == False:
        globalvars.chapter4_success = False
        return

    call_eagle()
    print("Chapter 4 complete!")
    globalvars.chapter4_success = True


# Unit test: runs only when this file is run by itself
if __name__ == '__main__':
    globalvars.init_global_vars()
    globalvars.player.supplies = 5     # pretend we finished chapter 1
    main()
    print("TEST RESULT -> success:", globalvars.chapter4_success,
          " wisdom:", globalvars.player.wisdom, " supplies:", globalvars.player.supplies)
