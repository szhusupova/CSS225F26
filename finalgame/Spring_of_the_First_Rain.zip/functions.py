# Helper functions used by maingame.py


# This shows a message when the player fails a chapter.
# It tells the player where they will be sent back to.
def fail_mesg(chapter):
    if chapter == 1:
        print("\nThe spring stays dry... the village waits for another hero.")
    elif chapter == 3:
        print("\nYou are lost in the mountains without a guide or clues.")
        print("You walk back to the yurt camp (Chapter 2) to ask for help.")
    elif chapter == 4:
        print("\nYou do not have enough supplies to wait out the storm.")
        print("You turn back to the village (Chapter 1) to get more supplies.")


# This asks the player a yes/no question.
# It gives back True for yes and False for anything else.
def ask_yes_no(question):
    answer = input(question + " (yes/no): ")
    if answer.casefold() == "yes" or answer.casefold() == "y":
        return True
    else:
        return False


def main():
    # Unit test for the helper functions
    fail_mesg(1)
    fail_mesg(3)
    fail_mesg(4)
    print("You said yes:", ask_yes_no("Do you like this game?"))


if __name__ == '__main__':
    main()
