# Main game file: The Spring of the First Rain
# This file decides which chapter the player goes to next.
# The player can go forward to the next chapter or go back to an
# earlier chapter, depending on how the last chapter went.
#
# Forward:
#   Chapter 1 success -> Chapter 2 -> Chapter 3 -> Chapter 4 -> Chapter 5
# Back:
#   Chapter 1 fail (said no to the journey) -> play Chapter 1 again
#   Chapter 3 fail (alone with only 1 clue)  -> back to Chapter 2
#   Chapter 4 fail (not enough supplies)     -> back to Chapter 1
import chapter1_dry_spring
import chapter2_high_pass
import chapter3_broken_bridge
import chapter4_echo_pass
import chapter5_springs_secret
import globalvars
import functions


def main():
    playing = True
    globalvars.init_global_vars()
    print("THE SPRING OF THE FIRST RAIN")
    print("Welcome,", globalvars.player.name)

    # This loop keeps running until the game is finished or the player quits
    while playing:

        if globalvars.currentChapter == 1:
            chapter1_dry_spring.main()
            if globalvars.chapter1_success:
                globalvars.currentChapter = 2       # go forward
            else:
                functions.fail_mesg(1)
                playing = functions.ask_yes_no("Do you want to try again?")

        elif globalvars.currentChapter == 2:
            chapter2_high_pass.main()
            if globalvars.chapter2_success:
                globalvars.currentChapter = 3       # go forward

        elif globalvars.currentChapter == 3:
            chapter3_broken_bridge.main()
            if globalvars.chapter3_success:
                globalvars.currentChapter = 4       # go forward
            else:
                functions.fail_mesg(3)
                globalvars.currentChapter = 2       # go back to chapter 2

        elif globalvars.currentChapter == 4:
            chapter4_echo_pass.main()
            if globalvars.chapter4_success:
                globalvars.currentChapter = 5       # go forward
            else:
                functions.fail_mesg(4)
                globalvars.currentChapter = 1       # go back to chapter 1

        elif globalvars.currentChapter == 5:
            chapter5_springs_secret.main()
            # The game is finished. We can start a new game or quit.
            if functions.ask_yes_no("Do you want to play again?"):
                globalvars.init_global_vars()
            else:
                playing = False

    print("\nThanks for playing!")


if __name__ == '__main__':
    main()
